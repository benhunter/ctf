/*   */ package htb.fatty.shared.message;
/*   */ 
/*   */ public class MessageLogoffException
/*   */   extends Exception {
/*   */   public MessageLogoffException(String s) {
/* 6 */     super(s);
/*   */   }
/*   */ }


/* Location:              /home/kali/ctf/htb/fatty-10.10.10.174/ftp/fatty-client.jar!/htb/fatty/shared/message/MessageLogoffException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */