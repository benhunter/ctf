/*    */ package htb.fatty.shared.connection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConnectionContext
/*    */ {
/*    */   public String hostname;
/*    */   public int port;
/*    */   
/*    */   public ConnectionContext(String hostname, int port) {
/* 12 */     this.hostname = hostname;
/* 13 */     this.port = port;
/*    */   }
/*    */ }


/* Location:              /home/kali/ctf/htb/fatty-10.10.10.174/ftp/fatty-client.jar!/htb/fatty/shared/connection/ConnectionContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */