package org.aopalliance.aop;

public interface Advice {}


/* Location:              /home/kali/ctf/htb/fatty-10.10.10.174/ftp/fatty-client.jar!/org/aopalliance/aop/Advice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */