package org.springframework.aop.framework;

public interface AopProxyFactory {
  AopProxy createAopProxy(AdvisedSupport paramAdvisedSupport) throws AopConfigException;
}


/* Location:              /home/kali/ctf/htb/fatty-10.10.10.174/ftp/fatty-client.jar!/org/springframework/aop/framework/AopProxyFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */